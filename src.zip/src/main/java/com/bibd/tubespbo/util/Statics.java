/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.bibd.tubespbo.util;

/**
 *
 * @author asthiseta
 */
public class Statics {
    
    public static String EMPLOYEE_STATUS_AKTIF = "aktif";
    public static String EMPLOYEE_STATUS_NONAKTIF = "nonaktif";
    
    public static String PRODUSEN_STATUS_ACTIVE = "active";
    public static String PRODUSEN_STATUS_NONACTIVE = "nonactive";
    
    public static String EMPLOYEE_ROLE_MANAGER = "manager";
    public static String EMPLOYEE_ROLE_SUPERVISOR = "supervisor";
    public static String EMPLOYEE_ROLE_SALES = "sales";
    
    public static String ORDER_TYPE_PENJUALAN = "penjualan";
    public static String ORDER_TYPE_PEMBELIAN = "pembelian";
    
    public static String SHIPMENT_STATUS_PENDING = "pending";
    public static String SHIPMENT_STATUS_SHIPPED = "shipped";
    
    public static String ORDER_PAYMENT_STATUS_PAID = "paid";
    public static String ORDER_PAYMENT_STATUS_UNPAID = "unpaid";
    public static String ORDER_PAYMENT_STATUS_CANCELLED = "cancelled";
    
    public static String PEMBELIAN_STATUS_PENDING = "pending";
    public static String PEMBELIAN_STATUS_REJECTED = "rejected";
    public static String PEMBELIAN_STATUS_RUNNING = "running";
    public static String PEMBELIAN_STATUS_FINNISH = "finnish";
    public static int GET_ALL_PEMBELIAN = 0;
    
    
}
