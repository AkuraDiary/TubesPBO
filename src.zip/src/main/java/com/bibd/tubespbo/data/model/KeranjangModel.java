/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.bibd.tubespbo.data.model;

/**
 *
 * @author rafid
 */
public class KeranjangModel {
    private int quantity ;
    private ProductModel produk ;
    

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public ProductModel getProduk() {
        return produk;
    }

    public void setProduk(ProductModel produk) {
        this.produk = produk;
    }
    
    
}
